#define MAX_JNT 200
#define JMAP_SIZE (MAX_JNT / 4)
#define MAX_JNT_PER_BATCH 16
#define JMTX_SIZE (MAX_JNT_PER_BATCH * 3)

