#!/bin/sh

BND_OPT=""
if [ "$#" -gt 0 ]; then
	if [ "$1" = "half" ]; then
		shift
		BND_OPT="-bndpath:bin/data/ostinato_half.bnd"
	fi
fi

PROG_PATH=bin/prog/ostinato
if [ ! -f "$PROG_PATH" ]; then
	PROG_PATH="$PROG_PATH""_`uname -m`"
fi

echo Running $PROG_PATH...
$PROG_PATH $BND_OPT -showperf:1 -show_ctrl_help:1 -glsl_echo:1 -nostgshadow:1 -vl:1 -smap:-1 -swap:0 $*
