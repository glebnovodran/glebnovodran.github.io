#!/bin/sh

VEMA_OPTS=
VEMA_CLIB=-DVEMA_NO_CLIB
if [ "$#" -gt 0 ]; then
	if [ "$1" = "vema" ]; then
		shift
		VEMA_OPTS="vema $VEMA_CLIB"
		#VEMA_OPTS= "$VEMA_OPTS -DXD_USE_VEMA_MTX"
		#VEMA_OPTS="$VEMA_OPTS -DVEMA_NEON -mfpu=neon"
	fi
fi

ARM_OPTS=
case `uname -m` in
	armv7l)
		ARM_OPTS="-DDRW_USE_MEMCMP=0 -DOGLSYS_INTERNAL_STRFN=1"
		ARM_OPTS="$ARM_OPTS -mfpu=neon"
	;;
esac

CORE_OPTS="-DXD_XMTX_CONCAT_VEC=1"

./build.sh $VEMA_OPTS $CORE_OPTS $ARM_OPTS -O3 -flto -fno-stack-protector -fno-exceptions $*
objdump -dC bin/prog/ostinato > ostinato_rpi.lst
