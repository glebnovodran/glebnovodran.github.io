/* SPDX-License-Identifier: MIT */
/* SPDX-FileCopyrightText: 2022 Glib Novodran <novodran@gmail.com> */

namespace Citizen {

ScnObj* add(const Human::Descr descr, const cxQuat& quat, const cxVec& pos);
int get_num();

};